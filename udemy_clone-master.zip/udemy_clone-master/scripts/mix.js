function logolink() {
  window.location.href = "index.html";
}
function cartPage() {
  window.location.href = "pages/cart.html";
}

function loginPage() {
  window.location.href = "pages/login.html";
}

function signupPage() {
  window.location.href = "pages/signup.html";
}

function exploreCourses() {
  window.location.href = "pages/categories.html";
}

function singleProduct() {
  window.location.href = "pages/product.html";
}
